import { useEffect, useMemo, useRef, useState } from "react";
import { BadgeCheck, CheckCircle2, ChevronRight, FileText, Flame, Play, RotateCcw, Shuffle, Map as MapIcon, Calculator, Rocket, Users, Store, Lightbulb, Zap, Wifi, Smartphone, Monitor } from "lucide-react";

type GameState = { playerName: string; email: string; pts: number; uang: number; level: number; bossIndex: number; contractSigned: boolean; buyers: string[]; sold: Record<string, number>; log: string[]; levelEarned: Record<string, number>; timeLeft: number; failStreak: number; totalDeals: number; totalFails: number; ownedCards: string[]; filledLevels: number[]; tenderUnlocked: boolean; };
const INITIAL: GameState = { playerName: "Bro Planner", email: "", pts: 0, uang: 0, level: 1, bossIndex: 0, contractSigned: false, buyers: [], sold: {}, log: ["Cerita dimulai! Sales jalan kanvas ke toko Bos. ACAK MODE ON — semua 30 level kebuka."], levelEarned: {}, timeLeft: 24, failStreak: 0, totalDeals: 0, totalFails: 0, ownedCards: [], filledLevels: [], tenderUnlocked: false };
const BOSSES = [
  { name: "Pak Haji", toko: "Toko Peralatan Teknis Elektronika Infrared — Bandung", city: "Bandung", emoji: "👨🏻‍💼", trait: "Owner toko infrared. Tegas, suka yang jelas & cepat. Pegang iPhone, cek dashboard dari HP." },
  { name: "Bu Sari", toko: "Toko Peralatan Teknis Elektronika Infrared — Jakarta", city: "Jakarta", emoji: "👩🏻‍💼", trait: "Owner toko infrared. Detail, nanya stok & harga dulu. Semua dicek dari HP." },
];
const CONTRACT = [
  { name: "MQ-135 — Sensor Gas", pts: 28, note: "Cium gas bahaya" },
  { name: "SHT41 — Sensor Suhu & Lembab", pts: 95, note: "Suhu + lembab keukur" },
  { name: "IMX219 — Kamera", pts: 210, note: "Foto detail, jernih" },
  { name: "ESP32-S3 — Otak Sistem", pts: 578, note: "Otaknya semua alat" },
  { name: "MLX90640 — Sensor Thermal / Infrared", pts: 1045, note: "Lihat titik panas" },
  { name: "Bio Health Room (MQ-135 + SHT41 + ESP32-S3)", pts: 701, note: "Kamar sehat, udara keukur" },
  { name: "Super IR Guard SG-810", pts: 1956, note: "Anti kebakaran + gas" },
  { name: "Gem Lab Obsidian", pts: 788, note: "Cek batu asli / palsu" },
  { name: "Color QC Batik", pts: 650, note: "Warna batik konsisten" },
  { name: "CCTV AI", pts: 578, note: "Jagain toko / rumah" },
  { name: "GPS Logistics", pts: 450, note: "Lacak kurir & barang" },
  { name: "SAAS SCM Accurate System", pts: 500, note: "Catat stok, order, uang" },
  { name: "UV Steril + Fogging", pts: 380, note: "Steril ruangan" },
  { name: "Sistem Marketing Digital", pts: 600, note: "Posting & promosi otomatis" },
];
type Buyer = { id: string; name: string; place: string; type: "satuan" | "banyak"; product: string; qty: number; unitPts: number; desc: string; emoji: string; min: number; max: number };
const BUYERS: Buyer[] = [
  { id: "ani", name: "Rumah Ibu Ani", place: "Perumahan", type: "satuan", product: "Bio Health Room", qty: 1, unitPts: 701, desc: "Buat kamar anak biar udaranya keukur.", emoji: "🏠", min: 1, max: 3 },
  { id: "rumah2", name: "Cluster Perumahan Baru", place: "Perumahan", type: "satuan", product: "Bio Health Room", qty: 1, unitPts: 701, desc: "1 rumah coba dulu, tetangga ikut.", emoji: "🏡", min: 1, max: 3 },
  { id: "klinik", name: "Klinik Sehat", place: "Perumahan", type: "satuan", product: "Bio Health Room", qty: 2, unitPts: 701, desc: "Ruang periksa harus paling bersih.", emoji: "🏥", min: 1, max: 3 },
  { id: "outlet1", name: "Outlet Baju — Butik", place: "Outlet", type: "satuan", product: "Sistem Marketing Digital", qty: 1, unitPts: 600, desc: "Outlet butuh yang postingin produk tiap hari.", emoji: "👗", min: 4, max: 5 },
  { id: "outlet2", name: "Outlet Sepatu & Tas", place: "Outlet", type: "satuan", product: "SAAS SCM Accurate System", qty: 1, unitPts: 500, desc: "Stok sepatu numpuk. SAAS bikin rapi.", emoji: "👟", min: 4, max: 5 },
  { id: "budi", name: "Ruko Pak Budi", place: "Ruko", type: "satuan", product: "CCTV AI", qty: 1, unitPts: 578, desc: "Ruko sering ditinggal. Butuh kamera yang jagain.", emoji: "🏪", min: 6, max: 8 },
  { id: "ruko2", name: "Ruko Fotokopi & ATK", place: "Ruko", type: "satuan", product: "SAAS SCM Accurate System", qty: 1, unitPts: 500, desc: "Stok ATK numpuk, order kececer.", emoji: "🏬", min: 6, max: 8 },
  { id: "toko1", name: "Toko Elektronik Tetangga", place: "Toko", type: "satuan", product: "CCTV AI", qty: 1, unitPts: 578, desc: "Etalase toko harus kejaga.", emoji: "🔌", min: 9, max: 10 },
  { id: "toko2", name: "Toko Sembako & ATK", place: "Toko", type: "banyak", product: "SAAS SCM Accurate System", qty: 2, unitPts: 500, desc: "Toko rame, stok harus nyambung.", emoji: "🧾", min: 9, max: 10 },
  { id: "sekolah", name: "Sekolah SMP", place: "Sekolah", type: "banyak", product: "UV Steril", qty: 20, unitPts: 380, desc: "20 kelas dipakai rame-rame.", emoji: "🎓", min: 11, max: 13 },
  { id: "sekolah2", name: "Sekolah — Lab Komputer", place: "Sekolah", type: "satuan", product: "Bio Health Room", qty: 1, unitPts: 701, desc: "Lab komputer harus adem & udaranya keukur.", emoji: "💻", min: 11, max: 13 },
  { id: "pasar", name: "Pasar Jaya — Kios Sembako", place: "Pasar Jaya", type: "banyak", product: "Bio Health Room", qty: 3, unitPts: 701, desc: "3 kios biar dagangan awet.", emoji: "🧺", min: 14, max: 16 },
  { id: "pasar2", name: "Pasar Jaya — Kios Sayur", place: "Pasar Jaya", type: "satuan", product: "SHT41 — Sensor Suhu & Lembab", qty: 1, unitPts: 95, desc: "Sayur gampang layu kalau lembab.", emoji: "🥬", min: 14, max: 16 },
  { id: "mal", name: "Mal City", place: "Mall", type: "banyak", product: "Bio Health Room", qty: 10, unitPts: 701, desc: "Food court + toilet harus segar.", emoji: "🏬", min: 17, max: 19 },
  { id: "mal2", name: "Mal — Food Court", place: "Mall", type: "banyak", product: "Sistem Marketing Digital", qty: 2, unitPts: 600, desc: "Tenant mal butuh promosi.", emoji: "🍔", min: 17, max: 19 },
  { id: "mini", name: "Mini Market Berkah", place: "Mini Market", type: "banyak", product: "CCTV AI", qty: 2, unitPts: 578, desc: "Buka sampai malam. 2 kamera biar aman.", emoji: "🏪", min: 20, max: 22 },
  { id: "mini2", name: "Mini Market — Gudang Kecil", place: "Mini Market", type: "satuan", product: "SAAS SCM Accurate System", qty: 1, unitPts: 500, desc: "Stok mini market harus nyambung.", emoji: "🛒", min: 20, max: 22 },
  { id: "super", name: "Supermarket Segar", place: "Supermarket", type: "banyak", product: "SAAS SCM Accurate System", qty: 3, unitPts: 500, desc: "3 cabang, stok harus nyambung.", emoji: "🛒", min: 23, max: 25 },
  { id: "super2", name: "Supermarket — Gudang Dingin", place: "Supermarket", type: "satuan", product: "MLX90640 — Sensor Thermal", qty: 1, unitPts: 1045, desc: "Freezer harus ketahuan kalau panas duluan.", emoji: "🧊", min: 23, max: 25 },
  { id: "dept", name: "Department Store", place: "Department Store", type: "banyak", product: "Super IR Guard SG-810", qty: 5, unitPts: 1956, desc: "Gudang gede, titik panas harus ketahuan duluan.", emoji: "🏢", min: 26, max: 27 },
  { id: "dept2", name: "Department Store — Lantai Fashion", place: "Department Store", type: "banyak", product: "Color QC Batik", qty: 3, unitPts: 650, desc: "Warna batik harus konsisten.", emoji: "👘", min: 26, max: 27 },
  { id: "pemda1", name: "Kelurahan — Kantor Lurah", place: "Dept Pemerintah", type: "satuan", product: "Bio Health Room", qty: 1, unitPts: 701, desc: "Kantor kelurahan harus nyaman buat warga.", emoji: "🏛️", min: 28, max: 30 },
  { id: "pemda2", name: "Kecamatan — Pelayanan Warga", place: "Dept Pemerintah", type: "banyak", product: "SAAS SCM Accurate System", qty: 2, unitPts: 500, desc: "Arsip & stok kecamatan harus rapi.", emoji: "📋", min: 28, max: 30 },
  { id: "pemda3", name: "Pemda — Gedung Dinas", place: "Dept Pemerintah", type: "banyak", product: "Super IR Guard SG-810", qty: 2, unitPts: 1956, desc: "Gedung dinas gede, keamanan infrared nomor satu.", emoji: "🏫", min: 28, max: 30 },
];
const MARKETS = [
  { name: "Perumahan", emoji: "🏠", levels: "Level 1–3", buyerId: "ani", note: "1 rumah coba dulu, tetangga ikut." },
  { name: "Outlet", emoji: "👗", levels: "Level 4–5", buyerId: "outlet1", note: "Outlet butuh yang postingin tiap hari." },
  { name: "Ruko", emoji: "🏪", levels: "Level 6–8", buyerId: "budi", note: "Ruko ditinggal, kamera yang jagain." },
  { name: "Toko", emoji: "🔌", levels: "Level 9–10", buyerId: "toko1", note: "Etalase toko harus kejaga." },
  { name: "Sekolah", emoji: "🎓", levels: "Level 11–13", buyerId: "sekolah", note: "Semua kelas harus steril." },
  { name: "Pasar Jaya", emoji: "🧺", levels: "Level 14–16", buyerId: "pasar", note: "Dagangan awet, udara segar." },
  { name: "Mall", emoji: "🏬", levels: "Level 17–19", buyerId: "mal", note: "Food court + toilet harus segar." },
  { name: "Mini Market", emoji: "🛒", levels: "Level 20–22", buyerId: "mini", note: "Buka sampai malam, harus aman." },
  { name: "Supermarket", emoji: "🧊", levels: "Level 23–25", buyerId: "super", note: "3 cabang, stok harus nyambung." },
  { name: "Department Store", emoji: "🏢", levels: "Level 26–27", buyerId: "dept", note: "Gudang gede, titik panas ketahuan duluan." },
  { name: "Dept Pemerintah", emoji: "🏛️", levels: "Level 28–30", buyerId: "pemda1", note: "Kelurahan, Kecamatan, Pemda." },
];
const CARDS = [
  { id: "senyum", name: "Kartu Senyum", price: 100, bonus: "+20% deal", desc: "Senyum dulu, Bos luluh.", emoji: "😊" },
  { id: "contoh", name: "Kartu Contoh Produk", price: 200, bonus: "+30% deal", desc: "Bos lihat contoh langsung.", emoji: "📦" },
  { id: "teknisi", name: "Kartu Teknisi Cepat", price: 150, bonus: "Rakit 2x cepat", desc: "Teknisi ngebut. Rakit 2x lebih cepat.", emoji: "⚡" },
];
type QtyOption = { id: string; label: string; short: string; qty: number; tender: boolean; hint: string };
const QTY_OPTIONS: QtyOption[] = [
  { id: "1", label: "SATUAN • 1 unit", short: "1 unit", qty: 1, tender: false, hint: "Jual 1 unit saja sudah naik level!" },
  { id: "5", label: "LEBIH • 5 unit", short: "5 unit", qty: 5, tender: false, hint: "Grosir kecil, PTS kali 5." },
  { id: "10", label: "LEBIH • 10 unit", short: "10 unit", qty: 10, tender: false, hint: "10+ unit = bonus +1 level!" },
  { id: "50", label: "TENDER • 50 unit", short: "50 unit", qty: 50, tender: true, hint: "Indent Full Design + Design fee 2.000 PTS." },
  { id: "tender", label: "TENDER INDEN • 100+", short: "TENDER 100+", qty: 100, tender: true, hint: "Indent Full Design — pesan dulu, baru rakit." },
];
const SAAS_PTS = 500; const MARKETING_PTS = 600; const DESIGN_FEE = 2000;
function calcSale(unitPts: number, qtyOpt: QtyOption, includeSystem: boolean) {
  const alat = unitPts * qtyOpt.qty;
  const saas = qtyOpt.tender ? SAAS_PTS : (includeSystem ? SAAS_PTS : 0);
  const sistem = qtyOpt.tender ? MARKETING_PTS : (includeSystem ? MARKETING_PTS : 0);
  const designFee = qtyOpt.tender ? DESIGN_FEE : 0;
  return { alat, saas, sistem, designFee, total: alat + saas + sistem + designFee };
}
function levelGainFor(q: QtyOption) { if (q.tender) return 3; if (q.qty >= 10) return 2; return 1; }
function levelInfo(n: number) {
  if (n <= 3) return { market: "Perumahan", tool: "Bio Health Room" };
  if (n <= 5) return { market: "Outlet", tool: "Marketing Digital + SAAS" };
  if (n <= 8) return { market: "Ruko", tool: "CCTV AI + SAAS" };
  if (n <= 10) return { market: "Toko", tool: "CCTV AI + SAAS" };
  if (n <= 13) return { market: "Sekolah", tool: "UV Steril + Bio Health" };
  if (n <= 16) return { market: "Pasar Jaya", tool: "Bio Health + SHT41" };
  if (n <= 19) return { market: "Mall", tool: "Bio Health x10 + Marketing" };
  if (n <= 22) return { market: "Mini Market", tool: "CCTV AI + SAAS" };
  if (n <= 25) return { market: "Supermarket", tool: "Super IR Guard + SAAS" };
  if (n <= 27) return { market: "Department Store", tool: "Super IR Guard + Color QC" };
  return { market: "Dept Pemerintah", tool: "Obsidian + SAAS + IR Guard" };
}
async function apiCall(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || `Gagal: ${action}`);
  return json.data;
}
type Stage = { salesPos: number; bossPos: number; salesBubble: string; bossBubble: string; techBubble: string; buyerBubble: string; salesMood: string; bossMood: string; techMood: string; buyerVisible: boolean; buyerPos: number; techActive: boolean; techProgress: number; techText: string; boxVisible: boolean; stageText: string; footsteps: boolean; ptsFloat: string; contractVisible: boolean; notaVisible: boolean; installVisible: boolean; bossBounce: boolean; };
const STAGE0: Stage = { salesPos: 4, bossPos: 82, salesBubble: "", bossBubble: "", techBubble: "", buyerBubble: "", salesMood: "🧑‍💼", bossMood: "normal", techMood: "normal", buyerVisible: false, buyerPos: 88, techActive: false, techProgress: 0, techText: "", boxVisible: false, stageText: "Panggung siap! Mulai dari LANGKAH 1 — Sales jalan kanvas ke toko.", footsteps: false, ptsFloat: "", contractVisible: false, notaVisible: false, installVisible: false, bossBounce: false };
const STEPS = ["1 Kanvas", "2 Tatap Muka", "3 Kontrak", "4 Bos → Teknisi", "5 Cari Buyer", "6 Teknisi Kerja", "7 Instalasi", "8 Transaksi"];

export default function App() {
  const [game, setGame] = useState<GameState>(INITIAL);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveNote, setSaveNote] = useState("Memuat progres…");
  const [toast, setToast] = useState("");
  const [showReset, setShowReset] = useState(false);
  const [step, setStep] = useState(1);
  const [selectedBuyer, setSelectedBuyer] = useState<Buyer | null>(null);
  const [qtyId, setQtyId] = useState("1");
  const [includeSystem, setIncludeSystem] = useState(true);
  const [calcProduct, setCalcProduct] = useState("Bio Health Room (MQ-135 + SHT41 + ESP32-S3)");
  const [lampOn, setLampOn] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [stage, setStage] = useState<Stage>(STAGE0);
  const [busy, setBusy] = useState(false);
  const recordIdRef = useRef<string | null>(null);
  const timers = useRef<number[]>([]);
  const playRef = useRef<HTMLDivElement>(null);
  const obsidianRef = useRef<HTMLElement>(null);
  const later = (fn: () => void, ms: number) => { const t = window.setTimeout(fn, ms); timers.current.push(t); return t; };
  useEffect(() => () => { timers.current.forEach((t) => window.clearTimeout(t)); }, []);
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await apiCall("records.list", { collection: "practical_game_state" });
        if (!alive) return;
        const rec = data?.records?.[0];
        if (rec?.value) {
          const v = rec.value as Partial<GameState>;
          setGame({ ...INITIAL, ...v, bossIndex: typeof v.bossIndex === "number" ? v.bossIndex % 2 : 0, buyers: Array.isArray(v.buyers) ? v.buyers : [], sold: (v.sold && typeof v.sold === "object") ? v.sold as Record<string, number> : {}, log: Array.isArray(v.log) ? v.log : INITIAL.log, level: typeof v.level === "number" ? Math.min(30, Math.max(1, v.level)) : 1, levelEarned: (v.levelEarned && typeof v.levelEarned === "object") ? v.levelEarned as Record<string, number> : {}, timeLeft: typeof v.timeLeft === "number" ? Math.max(0, Math.min(24, v.timeLeft)) : 24, failStreak: typeof v.failStreak === "number" ? v.failStreak : 0, totalDeals: typeof v.totalDeals === "number" ? v.totalDeals : 0, totalFails: typeof v.totalFails === "number" ? v.totalFails : 0, ownedCards: Array.isArray(v.ownedCards) ? v.ownedCards : [], filledLevels: Array.isArray(v.filledLevels) ? (v.filledLevels as number[]).filter((n) => typeof n === "number" && n >= 1 && n <= 30) : [], tenderUnlocked: Boolean(v.tenderUnlocked), email: typeof v.email === "string" ? v.email : "" });
          recordIdRef.current = rec.id; setSaveNote("Progres dimuat ✓");
        } else setSaveNote("Game langsung jalan — progres tersimpan otomatis");
      } catch { if (alive) setSaveNote("Mode offline — main dulu, progres tersimpan saat koneksi kembali"); }
      finally { if (alive) setLoading(false); }
    })();
    return () => { alive = false; };
  }, []);
  async function persist(next: GameState) {
    setSaving(true);
    try {
      if (recordIdRef.current) await apiCall("records.replace", { collection: "practical_game_state", id: recordIdRef.current, value: next });
      else { const created = await apiCall("records.create", { collection: "practical_game_state", value: next }); if (created?.id) recordIdRef.current = created.id; }
      setSaveNote("Tersimpan ✓");
    } catch { setSaveNote("Belum tersimpan — progres tetap di layar ini"); }
    finally { setSaving(false); }
  }
  function commit(next: GameState, message?: string) { setGame(next); persist(next); if (message) { setToast(message); later(() => setToast(""), 4200); } }
  function pushLog(next: GameState, text: string) { return { ...next, log: [text, ...next.log].slice(0, 8) }; }
  const boss = BOSSES[game.bossIndex % 2];
  const info = levelInfo(game.level);
  const dealChance = Math.min(0.95, 0.6 + (game.ownedCards.includes("senyum") ? 0.2 : 0) + (game.ownedCards.includes("contoh") ? 0.3 : 0));
  const fastBuild = game.ownedCards.includes("teknisi");
  const visibleBuyers = useMemo(() => BUYERS.filter((b) => game.level >= b.min && game.level <= b.max), [game.level]);
  const qtyOpt = QTY_OPTIONS.find((q) => q.id === qtyId) || QTY_OPTIONS[0];
  const calcContract = CONTRACT.find((c) => c.name === calcProduct) || CONTRACT[5];
  const calc = calcSale(calcContract.pts, qtyOpt, includeSystem);
  const filledCount = game.filledLevels.length;
  const filledPct = Math.round((filledCount / 30) * 100);
  const saleForBuyer = selectedBuyer ? calcSale(selectedBuyer.unitPts, qtyOpt, includeSystem) : null;
  const installKind = (() => {
    const p = (selectedBuyer?.product || calcProduct || "").toLowerCase();
    if (p.includes("obsidian") || p.includes("gem")) return "gem";
    if (p.includes("uv")) return "uv";
    if (p.includes("cctv")) return "cctv";
    if (p.includes("sg-810") || p.includes("thermal") || p.includes("mlx") || p.includes("infrared")) return "thermal";
    if (p.includes("bio") || p.includes("health")) return "room";
    if (p.includes("color") || p.includes("batik")) return "color";
    return "general";
  })();
  function showToast(m: string) { setToast(m); later(() => setToast(""), 3600); }

  // ---- STORY STEPS ----
  function step1() {
    setStep(1); setBusy(false);
    setStage((s) => ({ ...s, salesPos: 58, footsteps: true, salesBubble: "Halo Bos! Saya Sales Demand Planner, mau nawarin sistem kita.", bossBubble: "", techBubble: "", buyerBubble: "", contractVisible: false, stageText: "LANGKAH 1 • KANVAS — Sales jalan dari kiri ke toko Bos… 👣" }));
    later(() => setStage((s) => ({ ...s, footsteps: false, stageText: "Sales sampai di toko! Lanjut LANGKAH 2 — Ngobrol Tatap Muka." })), 1300);
  }
  function step2() {
    setStep(2);
    setStage((s) => ({ ...s, salesPos: 58, salesBubble: "Bos, ini sistem peralatan kita…", bossBubble: "", techBubble: "", stageText: "LANGKAH 2 • TATAP MUKA — Sales & Bos saling hadap…" }));
    later(() => setStage((s) => ({ ...s, bossBubble: "Coba jelasin… apa aja alatnya?", salesBubble: "" })), 1100);
    later(() => setStage((s) => ({ ...s, bossBubble: "", salesBubble: "ESP32-S3 otak, TCS34725 sensor warna, NDIR gas, IMX219 kamera, MLX90640 thermal, MQ-135 gas, SHT41 lembab." })), 2400);
    later(() => setStage((s) => ({ ...s, salesBubble: "", bossBubble: "Ooh… lengkap ya. Gue ngerti.", bossBounce: true, stageText: "Bos mengangguk — dia paham daftar alatnya. Lanjut LANGKAH 3 — Buat Kontrak." })), 4200);
    later(() => setStage((s) => ({ ...s, bossBounce: false, bossBubble: "" })), 5600);
  }
  function step3() {
    setStep(3);
    setStage((s) => ({ ...s, contractVisible: true, salesBubble: "Ini kontrak tertulisnya, Bos.", bossBubble: "Gue baca dulu ya…", stageText: "LANGKAH 3 • KONTRAK TERTULIS — Kertas kontrak muncul di tengah panggung." }));
    later(() => {
      const deal = Math.random() < dealChance;
      const att = attempts + 1; setAttempts(att);
      if (deal) {
        setStage((s) => ({ ...s, bossBubble: "Saya setuju, saya tanda tangan. DEAL! ✍️", bossBounce: true, stageText: "DEAL! Kontrak ditandatangani + stempel DEAL. Lanjut LANGKAH 4." }));
        const next = pushLog({ ...game, contractSigned: true, failStreak: 0 }, `DEAL! ${boss.name} tanda tangan kontrak. Sponsor aktif.`);
        commit(next, `DEAL! ${boss.name} tanda tangan kontrak!`);
        later(() => setStage((s) => ({ ...s, bossBounce: false, bossBubble: "" })), 3000);
      } else {
        setStage((s) => ({ ...s, contractVisible: false, bossBubble: "Belum dulu ya. Coba lagi, ketemu Bos lagi besok.", salesBubble: "Siap Bos, saya balik lagi.", salesPos: 4, stageText: "Belum deal — Sales jalan balik. Coba LANGKAH 1–3 lagi. Pertemuan ke-" + att + ". PTS aman, waktu -1 jam." }));
        const next = pushLog({ ...game, timeLeft: Math.max(0, game.timeLeft - 1), failStreak: game.failStreak + 1, totalFails: game.totalFails + 1 }, `Bos belum deal (percobaan ${att}). Coba lagi besok.`);
        commit(next, "Belum deal — coba lagi, ketemu Bos lagi besok.");
        later(() => setStage((s) => ({ ...s, bossBubble: "", salesBubble: "" })), 3000);
      }
    }, 1700);
  }
  function step4() {
    if (!game.contractSigned) { showToast("Buat kontrak dulu di LANGKAH 3 sampai Bos DEAL."); return; }
    setStep(4);
    setStage((s) => ({ ...s, contractVisible: false, bossPos: 52, bossBubble: "Bang Teknisi, ini kontrak alat kita. Tolong rakit ya kalau ada order.", salesBubble: "", techBubble: "", stageText: "LANGKAH 4 • BOS MAKLUMAT KE TEKNISI — Bos jalan ke meja Teknisi…" }));
    later(() => setStage((s) => ({ ...s, techBubble: "Siap Bos, saya maklum, saya siap rakit. 👍", bossBubble: "", stageText: "Teknisi maklum & siap rakit. Lanjut LANGKAH 5 — Cari Buyer." })), 1500);
    later(() => setStage((s) => ({ ...s, bossPos: 82, techBubble: "", stageText: "Bos balik ke toko. Teknisi standby di meja. Cari Buyer!" })), 3600);
  }
  function step5() {
    setStep(5);
    const b = selectedBuyer || visibleBuyers[0];
    if (b && !selectedBuyer) setSelectedBuyer(b);
    setStage((s) => ({ ...s, buyerVisible: true, buyerPos: 88, buyerBubble: "", salesBubble: "Cari buyer…", stageText: "LANGKAH 5 • CARI BUYER — Buyer jalan dari pasar…" }));
    later(() => setStage((s) => ({ ...s, buyerPos: 34, buyerBubble: "Saya mau pesan! Saya mau beli!", salesBubble: "Mau pesan apa, Bro?", notaVisible: true, stageText: "Buyer ketemu! Nota Order muncul di bawah panggung — pilih SATUAN / LEBIH / TENDER." })), 500);
    later(() => setStage((s) => ({ ...s, buyerBubble: "", salesBubble: "" })), 3200);
  }
  function step6() {
    if (!selectedBuyer) { showToast("Pilih buyer dulu di LANGKAH 5 — klik buyer di bawah atau tombol Cari Buyer."); step5(); return; }
    setStep(6);
    setStage((s) => ({ ...s, techActive: true, techProgress: 20, techText: "Teknisi bikin FULL DESIGN dulu… 📐", boxVisible: false, stageText: "LANGKAH 6 • PERINTAH KERJA — Teknisi kerja! Komponen terbang ke meja rakit." }));
    later(() => setStage((s) => ({ ...s, techProgress: 55, techText: "ESP32-S3 → Kapasitor → TCS34725 → IMX219…" })), 700);
    later(() => setStage((s) => ({ ...s, techProgress: 85, techText: "Solder… Coding… Cek fungsi…" })), 1400);
    later(() => setStage((s) => ({ ...s, techActive: false, techProgress: 100, techText: "Rakit selesai! Siap pasang. 📦", boxVisible: true, stageText: "Rakit selesai! Lanjut LANGKAH 7 — Instalasi Visual Nyata." })), 2100);
  }
  function step7() {
    if (!selectedBuyer) { showToast("Pilih buyer & rakit dulu — LANGKAH 5 lalu 6."); return; }
    setStep(7);
    setStage((s) => ({ ...s, installVisible: true, stageText: "LANGKAH 7 • INSTALASI VISUAL NYATA — Lihat panel instalasi di bawah panggung. Alat terpasang & berfungsi!" }));
  }
  function step8() {
    if (!selectedBuyer || !saleForBuyer) { showToast("Jalankan LANGKAH 5–7 dulu, baru transaksi."); return; }
    if (game.buyers.includes(selectedBuyer.id + ":" + qtyId)) { showToast("Transaksi ini sudah deal. Pilih buyer / jumlah lain untuk transaksi baru."); return; }
    setStep(8);
    const total = saleForBuyer.total; const gain = levelGainFor(qtyOpt); const newLevel = Math.min(30, game.level + gain);
    const newEarned = (game.levelEarned[String(game.level)] || 0) + total;
    const newFilled = game.filledLevels.includes(game.level) ? game.filledLevels : [...game.filledLevels, game.level];
    const key = selectedBuyer.id + ":" + qtyId;
    const next = pushLog({ ...game, pts: game.pts + total, uang: game.uang + total * 1000, buyers: [...game.buyers, key], sold: { ...game.sold, [selectedBuyer.id]: (game.sold[selectedBuyer.id] || 0) + 1 }, levelEarned: { ...game.levelEarned, [String(game.level)]: newEarned }, level: newLevel, filledLevels: newFilled, tenderUnlocked: game.tenderUnlocked || qtyOpt.tender, failStreak: 0, totalDeals: game.totalDeals + 1 }, `DEAL! ${selectedBuyer.name} beli ${qtyOpt.qty}x ${selectedBuyer.product} • +${total} PTS • Level +${gain} → Level ${newLevel}`);
    commit(next, `Yeay deal! +${total} PTS karena transaksi pembelian!`);
    setStage((s) => ({ ...s, salesBubble: `DEAL! +${total} PTS! 🎉`, bossBubble: "Mantap! Transaksi jalan! 😄", techBubble: "Terpasang! Berfungsi! 👍", buyerBubble: "Makasih! Alatnya nyala! 😄", ptsFloat: `+${total} PTS`, stageText: `LANGKAH 8 • TRANSAKSI — +${total} PTS karena transaksi pembelian. Semua senang!` }));
    later(() => setStage((s) => ({ ...s, salesBubble: "", bossBubble: "", techBubble: "", buyerBubble: "", ptsFloat: "" })), 3600);
  }
  function pickBuyer(b: Buyer) {
    setSelectedBuyer(b);
    setStage((s) => ({ ...s, buyerVisible: true, buyerPos: 34, buyerBubble: "Saya mau pesan!", salesBubble: `Ke ${b.name}!`, notaVisible: true, stageText: `Buyer dipilih: ${b.name} — ${b.product}. Nota Order muncul, pilih jumlah di bawah.` }));
    later(() => setStage((s) => ({ ...s, buyerBubble: "", salesBubble: "" })), 2400);
    playRef.current?.scrollIntoView({ behavior: "smooth" });
  }
  function randomLevel() {
    let n = game.level; while (n === game.level) n = Math.floor(Math.random() * 30) + 1;
    const next = pushLog({ ...game, level: n }, `🎲 RANDOM! Lompat ke Level ${n} — ${levelInfo(n).market}.`);
    commit(next, `🎲 RANDOM! Level ${n} — ${levelInfo(n).market}`);
    setSelectedBuyer(null);
    setStage((s) => ({ ...s, salesPos: 4, buyerVisible: false, boxVisible: false, techActive: false, installVisible: false, notaVisible: false, contractVisible: false, salesBubble: `Level ${n}!`, stageText: `🎲 RANDOM! Level ${n} — ${levelInfo(n).market}. Pilih buyer baru!` }));
    later(() => setStage((s) => ({ ...s, salesBubble: "" })), 2200);
  }
  function playLevel(n: number) {
    const next = pushLog({ ...game, level: n }, `Pindah ke Level ${n} — ${levelInfo(n).market}.`);
    commit(next, `Level ${n} aktif: ${levelInfo(n).market}`);
    setSelectedBuyer(null);
    setStage((s) => ({ ...s, salesPos: 4, buyerVisible: false, boxVisible: false, installVisible: false, notaVisible: false, stageText: `Pindah ke Level ${n} — ${levelInfo(n).market}!` }));
  }
  function jumpToGem() {
    const next = pushLog({ ...game, level: 28 }, `🚀 LOMPAT! Level 28 — Gem Store. Siap jual Obsidian.`);
    commit(next, "🚀 Lompat ke Level 28 — Gem Store!");
    setStage((s) => ({ ...s, buyerVisible: true, buyerPos: 34, buyerBubble: "Cek batu dong!", salesBubble: "Gem Store! Obsidian!", stageText: "🚀 LOMPAT ke Gem Store! Toko permata, Bro! 💎" }));
    later(() => setStage((s) => ({ ...s, buyerBubble: "", salesBubble: "" })), 2600);
    obsidianRef.current?.scrollIntoView({ behavior: "smooth" });
  }
  function nextBoss() {
    const next = pushLog({ ...game, bossIndex: (game.bossIndex + 1) % 2, contractSigned: false }, "Pindah toko — ketemu Bos lain.");
    commit(next, "Pindah toko — Bos baru!");
    setAttempts(0); setStep(1);
    setStage({ ...STAGE0, stageText: "Toko baru, Bos baru! Mulai lagi dari LANGKAH 1." });
  }
  function buyCard(cardId: string) {
    const card = CARDS.find((c) => c.id === cardId)!;
    if (game.ownedCards.includes(cardId)) return;
    if (game.pts < card.price) { showToast(`PTS belum cukup buat ${card.name}.`); return; }
    const next = pushLog({ ...game, pts: game.pts - card.price, ownedCards: [...game.ownedCards, cardId] }, `Beli ${card.name} — ${card.price} PTS.`);
    commit(next, `${card.name} aktif! ${card.bonus}`);
  }
  function resetDay() {
    const next = pushLog({ ...game, timeLeft: 24, failStreak: 0 }, "Hari baru! Waktu reset 24 jam.");
    commit(next, "Hari baru! Waktu balik 24 jam.");
    setStage((s) => ({ ...s, stageText: "🌙 Hari baru! Gas lagi!", salesBubble: "Hari baru! Gas!" }));
    later(() => setStage((s) => ({ ...s, salesBubble: "" })), 2000);
  }
  function resetGame() {
    const next: GameState = { ...INITIAL, playerName: game.playerName, email: game.email, log: ["Cerita diulang dari awal. ACAK MODE ON!"] };
    setShowReset(false); commit(next, "Cerita diulang dari awal. Gas lagi!"); setSelectedBuyer(null); setStep(1); setAttempts(0); setStage({ ...STAGE0, stageText: "Cerita diulang! Panggung balik ke awal." });
  }
  function saveInline() { persist(game); setToast("Nama & email tersimpan ✓"); later(() => setToast(""), 2500); }
  function pickQty(id: string) {
    if (id === "tender" && !game.tenderUnlocked) { showToast("TENDER 100+ terkunci — deal-in TENDER 50 dulu atau Tender Obsidian."); return; }
    setQtyId(id);
    const q = QTY_OPTIONS.find((x) => x.id === id);
    setStage((s) => ({ ...s, stageText: `Nota Order: ${q?.label} dipilih — PTS langsung kehitung!`, notaVisible: true }));
  }
  if (loading) return (<div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex items-center justify-center px-5"><div className="text-center"><div className="text-4xl mb-3">🧰</div><p className="font-display font-black text-xl">Practical Game — Sales Demand</p><p className="text-[var(--muted)] text-sm mt-1">Panggung visual siap dibuka…</p></div></div>);
  const salesEmoji = stage.salesBubble.includes("DEAL") ? "😄" : "🧑‍💼";
  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }} className="min-h-screen bg-[var(--bg)] text-[var(--text)] overflow-x-clip relative">
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-30 bg-[var(--bg)]/95 backdrop-blur border-b border-[var(--line)]">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 pt-2.5 pb-2">
          <div className="flex flex-wrap items-center gap-2">
            <div className="min-w-0 flex-1"><h1 className="font-display font-black leading-tight text-[clamp(1.05rem,5vw,1.6rem)] break-words">Sales / Demand Planner — Cerita Visual</h1><p className="text-[11px] text-[var(--muted)] break-words">FULL VISUAL STORY • Jalan toko ke toko • ACAK MODE • 30 LEVEL KEBUKA • Hanya 2 Bos</p></div>
            <span className="chip px-3 py-2 text-xs font-bold">⭐ {game.pts.toLocaleString("id-ID")} PTS</span><span className="chip px-3 py-2 text-xs font-bold">🎮 Level {game.level}/30</span><span className="chip px-3 py-2 text-xs font-bold">⏰ {game.timeLeft} jam</span>
          </div>
          <div className="mt-2 flex flex-wrap items-end gap-2">
            <label className="flex-1 min-w-[150px] bg-[var(--surface)] border border-[var(--line)] rounded-xl px-3 py-1.5 block"><span className="text-[10px] text-[var(--muted)] font-bold">NAMA ✏️</span><input value={game.playerName} onChange={(e) => setGame({ ...game, playerName: e.target.value.slice(0, 24) })} className="w-full bg-transparent outline-none font-display font-black text-[15px] leading-tight" placeholder="Nama lo, bro" /></label>
            <label className="flex-1 min-w-[170px] bg-[var(--surface)] border border-[var(--line)] rounded-xl px-3 py-1.5 block"><span className="text-[10px] text-[var(--muted)] font-bold">EMAIL (OPSIONAL)</span><input type="email" value={game.email} onChange={(e) => setGame({ ...game, email: e.target.value })} className="w-full bg-transparent outline-none font-bold text-[14px] leading-tight" placeholder="bro@email.com (boleh kosong)" /></label>
            <button onClick={saveInline} className="btn-emerald px-4 py-2.5 rounded-xl font-bold text-sm shrink-0">{saving ? "Menyimpan…" : "Simpan"}</button><span className="text-[11px] text-[var(--muted)]">{saveNote}</span><button onClick={() => setShowReset(true)} className="ml-auto text-xs font-bold underline underline-offset-4 text-[var(--muted)]">Ulang dari awal</button>
          </div>
          {showReset && (<div className="mt-2 bg-red-500/10 border border-red-400/40 rounded-xl px-3 py-2.5 flex flex-wrap gap-2 items-center"><span className="text-sm font-bold flex-1 min-w-[200px]">Ulang dari awal? PTS & level balik ke 0. Nama tetap disimpan.</span><button onClick={resetGame} className="bg-[var(--red)] text-white px-3 py-2 rounded-lg font-bold text-sm">Ya, Ulang</button><button onClick={() => setShowReset(false)} className="btn-ghost px-3 py-2 rounded-lg font-bold text-sm">Batal</button></div>)}
          <div className="mt-2"><div className="flex justify-between text-[11px] font-bold flex-wrap gap-1"><span>Peta 30 Level — {filledCount}/30 TERISI</span><span>{filledPct}% • Level Kamu: {game.level}</span></div><div className="progress-track h-2 mt-1"><div className="progress-fill" style={{ width: `${filledPct}%` }} /></div></div>
        </div>
        <nav className="max-w-6xl mx-auto px-4 pb-2.5"><div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5">
          <a href="#panggung" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-active no-underline text-[var(--text)]">🎮 Panggung</a>
          <a href="#pasar" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-inactive no-underline text-[var(--text)]">🛒 11 Pasar</a>
          <a href="#kalkulator" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-inactive no-underline text-[var(--text)]">🧮 Kalkulator + Tender</a>
          <a href="#peta" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-inactive no-underline text-[var(--text)]">🗺️ Peta 30 Level</a>
          <a href="#obsidian" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-inactive no-underline text-[var(--text)]">💎 Obsidian</a>
          <a href="#kartu" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-inactive no-underline text-[var(--text)]">🎴 Kartu</a>
          <a href="#kontrak" className="shrink-0 px-3 py-2 rounded-full border text-[12px] font-bold tab-inactive no-underline text-[var(--text)]">📄 Kontrak</a>
        </div></nav>
      </header>

      <main className="relative z-0 max-w-6xl mx-auto px-4 py-4 pb-10">
        {/* STAGE */}
        <section id="panggung" aria-label="Panggung Visual Game" className="rounded-[24px] border border-[var(--line)] overflow-hidden bg-white">
          <div className="relative h-[360px] w-full overflow-hidden" style={{ background: lampOn ? "linear-gradient(180deg,#fff7cc 0%,#fff3a0 55%,#ffd9a0 55%,#c9a86a 100%)" : "linear-gradient(180deg,#0b1e2e 0%,#122f45 55%,#2a2118 55%,#8a6a3a 100%)" }}>
            <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 bg-black/80 text-white px-4 py-1.5 rounded-full text-[12px] sm:text-sm font-black whitespace-nowrap shadow">📍 Level {game.level} — {info.market} • {boss.name} • Langkah {step}/8</div>
            <div className="absolute top-10 left-2 text-2xl">☁️</div><div className="absolute top-8 right-16 text-2xl">🌙</div>
            {lampOn && (<div className="absolute top-[58px] left-[8%] z-10 pointer-events-none"><div className="w-[260px] h-[90px] bg-yellow-300/70 blur-[2px]" style={{ clipPath: "polygon(0 42%, 100% 0, 100% 100%, 0 58%)" }} /><p className="text-[11px] font-black text-yellow-900 bg-yellow-300 px-2 py-0.5 rounded-full inline-block mt-1">💡 LAMPU ON — Cahaya memancar!</p></div>)}
            {/* TOKO */}
            <div className="absolute bottom-[70px] right-[1%] text-center z-10"><div className="text-[46px] leading-none">🏪</div><div className="bg-white/95 text-black text-[10px] font-black px-2 py-0.5 rounded-full mt-1 whitespace-nowrap">TOKO BOS • {boss.name}</div></div>
            <div className="absolute bottom-[70px] left-[1%] text-center z-10"><div className="text-[38px] leading-none">🏠</div><div className="bg-white/90 text-black text-[10px] font-black px-2 py-0.5 rounded-full mt-1">PASAR / RUMAH</div></div>
            {/* MEJA TEKNISI */}
            <div className="absolute bottom-[68px] left-[42%] -translate-x-1/2 text-center z-10"><div className="text-[26px] leading-none">🧰🔧</div><div className="bg-white/90 text-black text-[10px] font-black px-2 py-0.5 rounded-full mt-1 whitespace-nowrap">MEJA TEKNISI</div>
              {stage.techActive && (<div className="mt-1 w-[128px] bg-white rounded-full p-1 shadow"><div className="h-2 rounded-full bg-emerald-500 transition-all duration-500" style={{ width: `${stage.techProgress}%` }} /><p className="text-[9px] font-bold text-black mt-0.5">{stage.techText}</p></div>)}
              {!stage.techActive && stage.techText && <p className="mt-1 bg-white text-black text-[9px] font-bold px-2 py-0.5 rounded-full">{stage.techText}</p>}
            </div>
            {/* SALES */}
            <div className="absolute bottom-[78px] z-20 text-center transition-all duration-[1200ms] ease-in-out" style={{ left: `${stage.salesPos}%` }}>
              {stage.salesBubble && <div className="absolute -top-[72px] left-1/2 -translate-x-1/2 bg-white text-black text-[11px] font-bold px-2.5 py-1.5 rounded-xl shadow-lg w-[172px] text-center">{stage.salesBubble}</div>}
              <div className={`text-[54px] leading-none ${stage.footsteps ? "walk" : ""}`}>{salesEmoji}</div><div className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full mt-1 whitespace-nowrap">🧑‍💼 SALES (KAMU)</div>{stage.footsteps && <div className="text-lg mt-0.5">👣 👣</div>}
            </div>
            {/* BOSS */}
            <div className="absolute bottom-[78px] z-20 text-center transition-all duration-700 ease-in-out" style={{ left: `${stage.bossPos}%` }}>
              {stage.bossBubble && <div className="absolute -top-[72px] left-1/2 -translate-x-1/2 bg-yellow-300 text-black text-[11px] font-bold px-2.5 py-1.5 rounded-xl shadow-lg w-[172px] text-center">{stage.bossBubble}</div>}
              <div className={`text-[54px] leading-none ${stage.bossBounce ? "stage-bounce" : ""}`}>{boss.emoji}</div><div className="bg-orange-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full mt-1 whitespace-nowrap">👨‍💼 BOSS • {boss.name.toUpperCase()}</div>
            </div>
            {/* TEKNISI */}
            <div className="absolute bottom-[78px] left-[46%] -translate-x-1/2 z-20 text-center">
              {stage.techBubble && <div className="absolute -top-[72px] left-1/2 -translate-x-1/2 bg-sky-200 text-black text-[11px] font-bold px-2.5 py-1.5 rounded-xl shadow-lg w-[172px] text-center">{stage.techBubble}</div>}
              <div className={`text-[48px] leading-none ${stage.techActive ? "stage-hammer" : ""}`}>{stage.techActive ? "👨‍🔧🔨" : "👨‍🔧"}</div><div className="bg-sky-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full mt-1 whitespace-nowrap">👨‍🔧 TEKNISI</div>
            </div>
            {/* BUYER */}
            {stage.buyerVisible && (<div className="absolute bottom-[78px] z-20 text-center transition-all duration-700 ease-in-out" style={{ left: `${stage.buyerPos}%` }}>{stage.buyerBubble && <div className="absolute -top-[72px] left-1/2 -translate-x-1/2 bg-white text-black text-[11px] font-bold px-2.5 py-1.5 rounded-xl shadow-lg w-[150px] text-center">{stage.buyerBubble}</div>}<div className="text-[48px] leading-none">🧑</div><div className="bg-purple-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full mt-1 whitespace-nowrap">🧑 BUYER</div></div>)}
            {stage.boxVisible && (<div className="absolute bottom-[70px] left-[44%] z-30 text-center"><div className="text-[34px] leading-none">📦</div><div className="bg-black text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">PESANAN</div></div>)}
            {stage.ptsFloat && <div className="absolute top-[52px] left-1/2 -translate-x-1/2 z-30 bg-yellow-400 text-black font-black px-4 py-1.5 rounded-full text-base shadow-lg float-pts">{stage.ptsFloat}</div>}
            {/* CONTRACT PAPER */}
            {stage.contractVisible && (<div className="absolute inset-0 z-30 flex items-center justify-center bg-black/55 px-4"><div className="pop bg-[#fffdf2] text-black rounded-xl shadow-2xl max-w-[430px] w-full p-4 max-h-[310px] overflow-y-auto"><div className="flex justify-between items-start"><h3 className="font-black text-base leading-tight">📄 KONTRAK TERTULIS</h3><span className="bg-red-500 text-white text-[11px] font-black px-2 py-1 rounded-full rotate-[-6deg]">DEAL ✓</span></div><p className="text-[12px] leading-relaxed mt-2"><b>Bos Sponsor</b> memberi kerja ke <b>Sales</b>. Sales dapat <b>upah PTS per transaksi</b>. <b>Teknisi merakit</b> kalau ada order. Perintah kerja jalan kalau sudah ada pembeli.</p><div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px] font-semibold">{CONTRACT.map((c) => <div key={c.name} className="flex justify-between gap-1 border-b border-black/10 py-0.5"><span className="truncate">{c.name.split(" — ")[0]}</span><b>{c.pts} PTS</b></div>)}</div><div className="flex justify-between items-end mt-3"><div><p className="text-[10px] text-gray-500">Tanda tangan Bos:</p><p className="font-black italic text-lg leading-none">✍️ {boss.name}</p></div><div className="text-right"><p className="text-[10px] text-gray-500">Sales:</p><p className="font-black">{game.playerName || "Sales"}</p></div></div></div></div>)}
            <div className="absolute bottom-0 left-0 right-0 h-[62px] bg-[#8a6a3a] flex items-center justify-center"><div className="w-full border-t-4 border-dashed border-white/70 mx-2" /><span className="absolute text-white/95 text-[11px] font-black bg-black/50 px-3 py-1 rounded-full">🚶 JALAN CANVASSING — SALES JALAN DARI TOKO KE TOKO</span></div>
          </div>
          <div className="bg-[var(--surface)] px-3 py-2.5 flex flex-wrap gap-2 items-center"><span className="text-sm font-bold flex-1 min-w-[220px]">🎬 {stage.stageText}</span><span className="chip px-2.5 py-1 text-[11px] font-bold">Hanya 2 Bos: Pak Haji & Bu Sari</span><span className="chip px-2.5 py-1 text-[11px] font-bold">Kontrak: {game.contractSigned ? "✅ DEAL" : "Belum DEAL"}</span></div>
        </section>

        {/* STORY CONTROLS */}
        <section className="mt-3" aria-label="Langkah Cerita">
          <div className="flex flex-wrap gap-1.5">{STEPS.map((s, i) => <span key={s} className={`px-2.5 py-1.5 rounded-full text-[11px] font-bold border ${step === i + 1 ? "bg-emerald-500 text-black border-emerald-500" : "bg-[var(--surface)] border-[var(--line)]"}`}>{s}</span>)}</div>
          <div className="mt-2 grid grid-cols-2 lg:grid-cols-4 gap-2">
            <button onClick={step1} className="btn-orange px-3 py-3 rounded-2xl font-black text-sm">🚶 1 • JALAN KANVAS<br /><span className="text-[11px] font-semibold opacity-80">Sales jalan ke toko</span></button>
            <button onClick={step2} className="btn-orange px-3 py-3 rounded-2xl font-black text-sm">💬 2 • NGOBROL TATAP MUKA<br /><span className="text-[11px] font-semibold opacity-80">Sales sebutin alat</span></button>
            <button onClick={step3} className="bg-yellow-400 text-black px-3 py-3 rounded-2xl font-black text-sm hover:bg-yellow-300">📄 3 • BUAT KONTRAK<br /><span className="text-[11px] font-semibold opacity-80">Bos tanda tangan? 60% DEAL</span></button>
            <button onClick={step4} className="bg-sky-600 text-white px-3 py-3 rounded-2xl font-black text-sm hover:bg-sky-500">📣 4 • BOS KASIH TAU TEKNISI<br /><span className="text-[11px] font-semibold opacity-90">Bos jalan ke Teknisi</span></button>
            <button onClick={step5} className="bg-purple-600 text-white px-3 py-3 rounded-2xl font-black text-sm hover:bg-purple-500">🛒 5 • CARI BUYER<br /><span className="text-[11px] font-semibold opacity-90">Buyer muncul + Nota</span></button>
            <button onClick={step6} className="bg-sky-600 text-white px-3 py-3 rounded-2xl font-black text-sm hover:bg-sky-500">🔧 6 • TEKNISI KERJA<br /><span className="text-[11px] font-semibold opacity-90">Rakit: ESP32 → Kapasitor…</span></button>
            <button onClick={step7} className="btn-emerald px-3 py-3 rounded-2xl font-black text-sm">✨ 7 • INSTALASI NYATA<br /><span className="text-[11px] font-semibold opacity-80">Lihat alat berfungsi</span></button>
            <button onClick={step8} className="btn-emerald px-3 py-3 rounded-2xl font-black text-sm">💰 8 • TRANSAKSI + PTS<br /><span className="text-[11px] font-semibold opacity-80">+PTS karena transaksi</span></button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <button onClick={() => { setLampOn(!lampOn); setStage((s) => ({ ...s, stageText: !lampOn ? "💡 TES LAMPU: Tombol ON ditekan — cahaya memancar! Instalasi berfungsi nyata." : "💡 Lampu dimatikan. Tekan lagi untuk tes ON." })); }} className="bg-yellow-400 text-black px-4 py-2.5 rounded-full font-black text-sm flex items-center gap-2"><Lightbulb size={16} /> TES LAMPU: {lampOn ? "ON — Cahaya Nyala!" : "Klik ON"}</button>
            <button onClick={nextBoss} className="btn-ghost px-4 py-2.5 rounded-full font-bold text-sm">🔄 Ganti Bos: {boss.name} → {BOSSES[(game.bossIndex + 1) % 2].name}</button>
            <button onClick={randomLevel} className="btn-ghost px-4 py-2.5 rounded-full font-bold text-sm flex items-center gap-1"><Shuffle size={14} /> 🎲 Random Level</button>
            <button onClick={jumpToGem} className="btn-ghost px-4 py-2.5 rounded-full font-bold text-sm">💎 Lompat ke Gem Store (Lv 28)</button>
          </div>
        </section>
        {toast && <div className="mt-3 bg-[var(--surface-3)] border border-[var(--emerald)] rounded-2xl px-4 py-3 text-sm font-bold">{toast}</div>}
        {game.timeLeft === 0 && (<div className="mt-3 bg-red-500/10 border border-red-400/40 rounded-2xl px-4 py-3 flex flex-wrap gap-3 items-center"><span className="text-2xl">🌙</span><div className="flex-1 min-w-[200px]"><p className="font-bold text-sm">Waktu habis hari ini.</p><p className="text-[13px] text-[var(--muted)]">Besok lagi, cari lagi.</p></div><button onClick={resetDay} className="btn-emerald px-4 py-2.5 rounded-xl font-bold text-sm">Besok Lagi — Reset 24 Jam →</button></div>)}

        {/* NOTA ORDER */}
        {(stage.notaVisible || selectedBuyer) && selectedBuyer && (
          <section className="mt-3 card p-4" aria-label="Nota Order">
            <div className="flex flex-wrap justify-between gap-2 items-start"><div><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">NOTA ORDER DARI BUYER • LANGKAH 5</p><h2 className="font-display font-black text-xl mt-1">🧾 Nota Order — {selectedBuyer.name}</h2><p className="text-sm text-[var(--muted)]">{selectedBuyer.place} • {selectedBuyer.desc}</p></div><span className="chip px-3 py-1.5 text-xs font-bold">{qtyOpt.tender ? "TENDER • INDENT FULL DESIGN" : "ORDER BIASA"}</span></div>
            <div className="mt-3 grid sm:grid-cols-2 gap-3">
              <div className="bg-[var(--surface-2)] rounded-xl p-3 text-sm leading-relaxed"><p><b>Produk:</b> {selectedBuyer.product}</p><p><b>Jumlah:</b> {qtyOpt.qty}x @ {selectedBuyer.unitPts} PTS = {(saleForBuyer?.alat || 0).toLocaleString("id-ID")} PTS</p>{qtyOpt.tender && <p><b>Design fee Full Design:</b> +2.000 PTS</p>}<p><b>SAAS SCM:</b> +{(saleForBuyer?.saas || 0).toLocaleString("id-ID")} PTS • <b>Sistem Marketing:</b> +{(saleForBuyer?.sistem || 0).toLocaleString("id-ID")} PTS</p><p className="mt-1 text-base"><b>TOTAL: {(saleForBuyer?.total || 0).toLocaleString("id-ID")} PTS • Level +{levelGainFor(qtyOpt)}</b></p><p className="text-xs text-[var(--muted)] mt-1">{qtyOpt.tender ? "Buyer pesan dulu (indent) → Teknisi bikin full design → baru rakit → baru kirim." : "Order langsung — Teknisi rakit, lalu pasang."}</p></div>
              <div><p className="text-xs font-bold text-[var(--muted)]">PILIH JENIS ORDER — SEMUA PASAR BISA SEMUA PILIHAN</p><div className="grid grid-cols-2 gap-2 mt-2">{QTY_OPTIONS.map((q) => <button key={q.id} onClick={() => pickQty(q.id)} className={`px-3 py-2.5 rounded-xl text-left border font-bold text-sm ${qtyId === q.id ? "bg-emerald-500 text-black border-emerald-500" : "btn-ghost"}`}><span className="block">{q.label} {qtyId === q.id ? "✓" : ""}</span><span className={`block text-[11px] font-semibold ${qtyId === q.id ? "text-black/70" : "text-[var(--muted)]"}`}>{q.hint}</span></button>)}</div><label className="flex items-center gap-2 mt-2 bg-[var(--surface-2)] border border-[var(--line)] rounded-xl px-3 py-2.5 cursor-pointer"><input type="checkbox" checked={includeSystem} onChange={(e) => setIncludeSystem(e.target.checked)} /><span className="text-sm font-bold">Paket Sistem Lengkap (+1.100 PTS)</span></label></div>
            </div>
          </section>
        )}

        {/* INSTALLASI */}
        {stage.installVisible && selectedBuyer && (
          <section className="mt-3 card p-4 sm:p-5" aria-label="Instalasi Visual Nyata">
            <p className="text-xs font-bold tracking-[0.18em] text-[var(--emerald-2)]">LANGKAH 7 • INSTALASI VISUAL NYATA • {selectedBuyer.product.toUpperCase()}</p>
            <h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] mt-1">Terpasang Dengan Benar, Aktif Berfungsi ✅</h2>
            <p className="text-[13px] text-[var(--muted)] leading-relaxed mt-1">Ini patokan dunia nyata. Urutan pasang: <b className="text-white">ESP32-S3 (otak) → Kapasitor (cadangan daya) → TCS34725 + IMX219 → WiFi → HP & Laptop</b>. Kapasitor bantu daya stabil supaya TCS34725 & IMX219 deteksi dengan baik.</p>
            {installKind === "room" && (<div className="mt-3 grid sm:grid-cols-2 gap-3"><div className="bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">🏠 BIO HEALTH ROOM — Kamar Sehat</p><div className="mt-3 bg-black/40 rounded-xl p-3 text-center relative overflow-hidden"><div className="text-5xl">🛏️</div><div className="text-3xl animate-spin" style={{ animationDuration: "2s" }}>🌀</div><p className="text-[12px] font-bold text-emerald-300 mt-1">Kipas muter • Udara jadi bersih ✨</p><div className="flex justify-center gap-2 mt-2"><span className="chip px-2 py-1 text-[11px] font-bold">MQ-135: Gas aman ✓</span><span className="chip px-2 py-1 text-[11px] font-bold">SHT41: Lembab pas ✓</span></div></div><p className="text-[12px] text-[var(--muted)] mt-2">Ruangan tanpa timbal & debu berlebih — sensor kirim data ke HP, kipas jalan otomatis.</p></div><div className="bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">🔥 ANTI KEBAKARAN — Diagram Nyata</p><div className="mt-3 space-y-2 text-[13px] font-bold"><div className="flex items-center gap-2 bg-black/30 rounded-lg px-3 py-2"><span className="text-xl">🧠</span> ESP32-S3 = OTAK <Wifi size={16} className="text-emerald-400" /> WiFi</div><div className="text-center text-[var(--muted)]">↓ terkoneksi internet ↓</div><div className="flex gap-2"><span className="flex-1 bg-black/30 rounded-lg px-2 py-2 text-center text-[12px]"><Smartphone size={14} className="inline" /> HP — Alert!</span><span className="flex-1 bg-black/30 rounded-lg px-2 py-2 text-center text-[12px]"><Monitor size={14} className="inline" /> Laptop</span></div><div className="flex items-center gap-2 bg-black/30 rounded-lg px-3 py-2"><span className="text-xl">🔋</span> Kapasitor — cadangan daya</div><div className="flex items-center gap-2 bg-black/30 rounded-lg px-3 py-2"><span className="text-xl">👁️</span> TCS34725 + IMX219 — deteksi api, gas, debu</div></div><div className="mt-3 bg-red-500/15 border border-red-400/40 rounded-xl px-3 py-2 flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-red-500 pulse-soft shrink-0" /><p className="text-[12px] font-bold">Sensor berkedip — HP bunyi alert, lampu ON, cahaya memancar!</p></div></div></div>)}
            {installKind === "thermal" && (<div className="mt-3 bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">🌡️ SG-810 / THERMAL — Scan Titik Panas</p><div className="mt-3 bg-black/50 rounded-xl p-4 relative overflow-hidden"><div className="flex justify-between text-2xl"><span>🧱</span><span className="text-red-500 pulse-soft">🔴 TITIK PANAS!</span><span>🧱</span></div><div className="mt-2 h-2 bg-gradient-to-r from-blue-500 via-yellow-400 to-red-600 rounded-full" /><p className="text-[12px] font-bold text-red-300 mt-2">🚨 Alarm bunyi! MLX90640 lihat panas yang mata nggak lihat.</p><div className="mt-2 flex gap-2"><span className="chip px-2 py-1 text-[11px] font-bold">ESP32-S3 kirim ke HP</span><span className="chip px-2 py-1 text-[11px] font-bold">Kapasitor stabil</span></div></div></div>)}
            {installKind === "gem" && (<div className="mt-3 bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">💎 GEM LAB OBSIDIAN — Cek Batu</p><div className="mt-3 bg-black/50 rounded-xl p-4 text-center"><div className="text-6xl">💎</div><div className="text-3xl mt-1">📸 ⚡</div><p className="text-[12px] font-bold mt-1">Kamera IMX219 flash — TCS34725 baca warna batu</p><div className="inline-block mt-2 bg-emerald-500 text-black font-black px-4 py-1.5 rounded-full rotate-[-4deg]">ASLI ✓ STAMP</div><p className="text-[12px] text-[var(--muted)] mt-2">Pelanggan percaya karena ada bukti cek batu.</p></div></div>)}
            {installKind === "uv" && (<div className="mt-3 bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">🟣 UV STERIL — Cahaya Ungu</p><div className="mt-3 bg-purple-950 rounded-xl p-4 text-center relative overflow-hidden"><div className="text-5xl">💡</div><div className="mx-auto mt-2 h-6 w-full max-w-[280px] bg-purple-400/80 blur-[1px] rounded-full" /><p className="text-[12px] font-bold text-purple-200 mt-2">Sinar UV ungu menyapu ruangan • Kuman hilang ✨</p><div className="flex justify-center gap-2 mt-2 text-xl"><span className="opacity-30 line-through">🦠</span><span className="opacity-30 line-through">🦠</span><span>✨ Bersih!</span></div></div></div>)}
            {installKind === "cctv" && (<div className="mt-3 bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">📹 CCTV AI — Mata Kamera</p><div className="mt-3 bg-black/50 rounded-xl p-4 text-center"><div className="text-6xl">📹</div><div className="text-2xl mt-1"><span className="pulse-soft">👁️</span> <span className="text-red-500 font-black text-sm">● REC</span></div><p className="text-[12px] font-bold mt-1">Mata kamera berkedip • Merekam • Kirim ke HP Bos</p></div></div>)}
            {installKind === "color" && (<div className="mt-3 bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">🎨 COLOR QC BATIK — Warna Konsisten</p><div className="mt-3 bg-black/50 rounded-xl p-4 text-center"><div className="text-5xl">👘</div><div className="flex justify-center gap-2 mt-2"><span className="w-8 h-8 rounded-full bg-red-500 inline-block" /><span className="w-8 h-8 rounded-full bg-red-500 inline-block" /><span className="w-8 h-8 rounded-full bg-red-500 inline-block" /></div><p className="text-[12px] font-bold mt-2">TCS34725 baca warna — 3 batch, warna sama persis ✓</p></div></div>)}
            {installKind === "general" && (<div className="mt-3 bg-[var(--surface-2)] rounded-2xl p-4"><p className="font-black text-sm">⚙️ INSTALASI — {selectedBuyer.product}</p><p className="text-[13px] text-[var(--muted)] mt-1">ESP32-S3 otak → Kapasitor cadangan daya → Sensor + Kamera → WiFi → HP & Laptop. Cek lampu indikator nyala, cek dashboard HP, cek fungsi utama jalan.</p><div className="mt-2 flex flex-wrap gap-2"><span className="chip px-2 py-1 text-[11px] font-bold">🧠 ESP32-S3 ON ✓</span><span className="chip px-2 py-1 text-[11px] font-bold">🔋 Kapasitor ✓</span><span className="chip px-2 py-1 text-[11px] font-bold">📶 WiFi ke HP ✓</span></div></div>)}
            <div className="mt-3 flex flex-wrap gap-2 items-center"><button onClick={() => setLampOn(!lampOn)} className="bg-yellow-400 text-black px-4 py-2.5 rounded-full font-black text-sm flex items-center gap-2"><Lightbulb size={16} /> TES LAMPU: {lampOn ? "ON — Cahaya Memancar!" : "Klik ON"}</button><span className="text-[13px] font-bold">Terpasang dengan benar, aktif berfungsi sesuai instalasi yang dicontohkan. Ini patokan dunia nyata.</span></div>
            {lampOn && <div className="mt-3 bg-yellow-300/15 border border-yellow-400/50 rounded-xl px-3 py-2 text-sm font-bold text-yellow-200">💡 Lampu senter ON — cahaya memancar, ruangan terang. Bukti instalasi berfungsi nyata, bukan cuma gambar diam.</div>}
          </section>
        )}

        <div ref={playRef} className="mt-5 grid lg:grid-cols-5 gap-3">
          <section className="lg:col-span-3 card p-4 sm:p-5"><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">CANVASSING • LEVEL KAMU: {game.level}/30 • RANDOM BEBAS</p><h2 className="font-display font-black text-[clamp(1.5rem,6vw,2.2rem)] leading-tight">Level {game.level} — {info.market}</h2><p className="text-[var(--muted)] text-sm mt-1">Alat: {info.tool} • Peluang DEAL: {Math.round(dealChance * 100)}% • Sisa {game.timeLeft} jam</p><p className="mt-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-3 py-2 text-[13px] font-bold">🚶 Lu lagi canvassing di {info.market}. ✅ Jual 1 unit saja sudah naik level! Semua pasar: 1 unit / banyak / TENDER indent.</p><div className="mt-3 flex flex-wrap gap-2"><span className="chip px-3 py-1.5 text-xs font-bold">🎯 Level ini: {(game.levelEarned[String(game.level)] || 0).toLocaleString("id-ID")} PTS</span><span className="chip px-3 py-1.5 text-xs font-bold">🗺️ Terisi {filledCount}/30</span><span className="chip px-3 py-1.5 text-xs font-bold">Bos aktif: {boss.name} — {boss.city}</span></div><div className="mt-4 grid sm:grid-cols-2 gap-2"><button onClick={randomLevel} className="btn-emerald px-4 py-3.5 rounded-2xl font-black flex items-center justify-center gap-2"><Shuffle size={18} /> 🎲 Random Level</button><button onClick={step1} className="btn-orange px-4 py-3.5 rounded-2xl font-black flex items-center justify-center gap-2"><Play size={18} /> Mulai Cerita — Langkah 1</button></div><div className="mt-4 bg-black/20 rounded-xl p-3 text-[13px] leading-relaxed"><b className="text-white">Aturan Beli — Semua Pasar:</b><br />1 unit ✅ • Lebih dari 1 unit ✅ • <b className="text-orange-200">TENDER = INDENT FULL DESIGN</b> — buyer pesan dulu, teknisi bikin full design, baru rakit, baru kirim.</div></section>
          <section className="lg:col-span-2 card p-4 sm:p-5"><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">SPONSOR • HANYA 2 BOS • CEPAT AKTIF</p><div className="flex gap-3 items-start mt-2"><div className="text-center shrink-0"><div className="text-[56px] leading-none">{boss.emoji}</div><p className="text-[11px] font-bold mt-1">BOSS SPONSOR</p></div><div className="min-w-0 flex-1"><h3 className="font-display font-black text-xl leading-tight">{boss.name}</h3><p className="text-xs text-[var(--muted)] leading-relaxed">{boss.toko} • {boss.trait}</p></div></div><div className="dialogue mt-3"><p className="text-[11px] font-bold tracking-widest text-[var(--emerald-2)]">LU • SALES / DEMAND PLANNER</p><p className="text-[15px] leading-relaxed mt-1">“Bos mau jadi sponsor saya nggak? Nih saya ada sistem ini yang bisa memasarkan produk-produknya si Bos nih.”</p></div>{game.contractSigned ? <div className="mt-3 bg-emerald-500/15 border border-emerald-500/40 rounded-xl px-3 py-3 text-sm font-bold">🎉 DEAL! Sponsor aktif. Kontrak + Teknisi jalan.<button onClick={nextBoss} className="mt-2 w-full btn-ghost px-3 py-2 rounded-xl text-xs font-bold">Cari Toko / Bos Lain →</button></div> : <><button onClick={step3} className="mt-3 btn-orange px-4 py-3.5 rounded-xl w-full font-bold">Buat Kontrak → Bos Jawab</button><button onClick={nextBoss} className="mt-2 btn-ghost px-4 py-2.5 rounded-xl w-full font-bold text-sm">Ganti Bos → {BOSSES[(game.bossIndex + 1) % 2].name}</button></>}<p className="text-xs text-[var(--muted)] mt-2 text-center">Bos jawab: DEAL 60% 😄 / Belum 40% 😔. Kalau belum, coba lagi 2–3x pertemuan — cepat kok. PTS aman.</p></section>
        </div>

        <section className="mt-8" aria-label="Pelaku Pasar dan Pelaku Kerja"><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">PELAKU PASAR & PELAKU KERJA</p><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] flex items-center gap-2"><Users size={22} className="text-[var(--emerald-2)]" /> Siapa Aja yang Main?</h2><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">{[{ e: "🗣️", t: "Sales / Demand Planner", d: "YOU — AKTIF. Canvassing, jalan toko ke toko, nawarin sistem, cari buyer.", a: true }, { e: "👨‍🔧", t: "Teknisi Elektronika", d: "Dari sponsor. Bikin full design dulu, baru rakit, solder, coding.", a: false }, { e: "👨‍💼", t: "Boss Sponsor — Owner Toko Infrared", d: "Pak Haji (Bandung) & Bu Sari (Jakarta). Setujui kontrak, kasih upah PTS.", a: false }, { e: "📒", t: "Admin / Finance", d: "Catat PTS / uang, catat order biar nggak ketuker.", a: false }, { e: "🛵", t: "Logistik / Kurir", d: "Antar barang ke buyer, pastiin sampai aman.", a: false }, { e: "🛒", t: "Buyer / Pembeli", d: "Pelaku Pasar di 11 pasar. Beli 1 unit, banyak unit, atau TENDER.", a: false }].map((c) => <article key={c.t} className={`card p-4 ${c.a ? "border-emerald-500/60 bg-emerald-500/5" : ""}`}><span className="text-3xl">{c.e}</span><h3 className="font-display font-black text-[15px] mt-2">{c.t}</h3><p className="text-[13px] text-[var(--muted)] mt-1 leading-relaxed">{c.d}</p></article>)}</div></section>

        <section id="pasar" className="mt-8" aria-label="11 Pasar"><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">11 PASAR • SEMUA BISA 1 / BANYAK / TENDER</p><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] mt-1 flex items-center gap-2"><Store size={22} /> Semua Pasar Bisa Dibeli 🛒</h2><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">{MARKETS.map((m) => { const b = BUYERS.find((x) => x.id === m.buyerId)!; return (<article key={m.name} className="card p-4 flex flex-col"><div className="flex justify-between items-start"><span className="text-3xl">{m.emoji}</span><span className="chip px-2.5 py-1 text-[11px] font-bold">{m.levels}</span></div><h3 className="font-display font-black text-lg mt-2">{m.name}</h3><p className="text-[13px] font-bold mt-0.5">{b.name} — {b.product}</p><p className="text-[13px] text-[var(--muted)] mt-1 flex-1">{m.note}</p><p className="text-[12px] font-bold text-[var(--emerald-2)] mt-2">Bisa: 1 unit ✅ • Banyak ✅ • TENDER ✅</p><div className="grid grid-cols-2 gap-2 mt-3"><button onClick={() => playLevel(b.min)} className="btn-ghost px-3 py-2.5 rounded-xl font-bold text-xs">Canvassing ke Sini →</button><button onClick={() => pickBuyer(b)} className="btn-emerald px-3 py-2.5 rounded-xl font-bold text-xs">Pilih Buyer Ini →</button></div></article>); })}</div></section>

        <section className="mt-8" aria-label="Buyer Level Ini"><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)]">Cari Buyer — Level {game.level} 🛒</h2><p className="text-[var(--muted)] text-sm">Pasar: <b className="text-white">{info.market}</b> • Jumlah aktif: <b className="text-white">{qtyOpt.label}</b> • Klik buyer → Nota muncul → Langkah 6–8.</p><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">{visibleBuyers.map((b) => { const done = game.buyers.includes(b.id + ":" + qtyId); const c = calcSale(b.unitPts, qtyOpt, includeSystem); return (<article key={b.id} className="card p-4 flex flex-col"><div className="flex justify-between items-start"><span className="text-3xl">{b.emoji}</span><span className="chip px-2.5 py-1 text-[11px] font-bold">{b.type === "banyak" ? "BANYAK / GROSIR" : "SATUAN"}</span></div><h3 className="font-display font-black text-lg mt-2 leading-tight">{b.name}</h3><p className="text-xs text-[var(--muted)]">{b.place}</p><p className="text-[13px] text-[var(--muted)] mt-2 flex-1 leading-relaxed">{b.desc}</p><div className="mt-3 bg-[var(--surface-2)] rounded-xl px-3 py-2 text-[13px]"><b className="text-[var(--emerald-2)]">Produk:</b> {b.product}<br /><b>TOTAL:</b> {c.total.toLocaleString("id-ID")} PTS • Level +{levelGainFor(qtyOpt)}</div>{selectedBuyer?.id === b.id ? <div className="mt-3 bg-emerald-500/15 border border-emerald-500/40 rounded-xl px-3 py-2.5 text-sm font-bold flex items-center gap-2"><CheckCircle2 size={18} /> Buyer Dipilih — Nota di atas ✓</div> : <button onClick={() => pickBuyer(b)} className="mt-3 btn-emerald px-4 py-3 rounded-xl w-full font-bold text-sm">Pilih Buyer Ini → {c.total.toLocaleString("id-ID")} PTS</button>}</article>); })}</div></section>

        <section id="kalkulator" className="mt-8 card p-4 sm:p-5" aria-label="Kalkulator PTS dan Tender"><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">KALKULATOR PTS + TENDER • LIVE</p><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] mt-1 flex items-center gap-2"><Calculator size={22} /> Pilih Jumlah — PTS Langsung Kehitung 🧮</h2><p className="text-[13px] text-[var(--muted)]">Rumus: <b className="text-white">PTS = per unit × jumlah + sistem</b>. <b className="text-orange-200">TENDER: unit × qty + Design 2.000 + SAAS 500 + Sistem 600.</b></p><div className="mt-4"><p className="text-xs font-bold text-[var(--muted)]">1) PILIH PRODUK</p><label className="block mt-1"><span className="sr-only">Pilih produk</span><select value={calcProduct} onChange={(e) => setCalcProduct(e.target.value)} className="w-full bg-[var(--surface-2)] border border-[var(--line)] rounded-xl px-3 py-3 font-bold text-sm text-[var(--text)]">{CONTRACT.map((c) => <option key={c.name} value={c.name}>{c.name} — {c.pts} PTS</option>)}</select></label></div><div className="mt-4"><p className="text-xs font-bold text-[var(--muted)]">2) PILIH JUMLAH</p><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 mt-2">{QTY_OPTIONS.map((q) => <button key={q.id} onClick={() => pickQty(q.id)} className={`px-3 py-3 rounded-xl text-left border font-bold text-sm ${qtyId === q.id ? "bg-emerald-500 text-black border-emerald-500" : "btn-ghost"}`}><span className="block">{q.label} {qtyId === q.id ? "✓" : ""}</span><span className={`block text-[11px] font-semibold mt-0.5 ${qtyId === q.id ? "text-black/70" : "text-[var(--muted)]"}`}>{q.hint}</span></button>)}</div><p className="text-xs text-[var(--muted)] mt-2">Tender Mode: {game.tenderUnlocked ? "🔓 KEBUKA" : "🔒 Terkunci — deal-in TENDER 50 dulu."} • Tender kecil 50 unit udah kebuka.</p></div><div className="mt-4 bg-[var(--surface-2)] border border-[var(--line)] rounded-2xl p-4"><p className="text-xs font-bold tracking-widest text-[var(--emerald-2)]">STRUK LIVE — {calcContract.name} • {qtyOpt.short}</p><div className="mt-3 space-y-1.5 text-sm"><div className="flex justify-between gap-2"><span>Alat: {calcContract.pts} × {qtyOpt.qty}</span><b>{calc.alat.toLocaleString("id-ID")} PTS</b></div>{qtyOpt.tender && <div className="flex justify-between gap-2 text-purple-200"><span>Design fee — Full Design</span><b>+2.000 PTS</b></div>}<div className="flex justify-between gap-2"><span>SAAS SCM</span><b>{calc.saas.toLocaleString("id-ID")} PTS</b></div><div className="flex justify-between gap-2"><span>Sistem Marketing</span><b>{calc.sistem.toLocaleString("id-ID")} PTS</b></div><div className="border-t border-[var(--line)] pt-2 flex justify-between gap-2 text-base"><span className="font-black">TOTAL</span><span className="font-display font-black text-[var(--emerald-2)] text-xl">{calc.total.toLocaleString("id-ID")} PTS</span></div></div></div></section>

        <section id="peta" className="mt-8" aria-label="Peta 30 Level"><div className="card p-4 sm:p-5"><p className="text-xs font-bold tracking-[0.18em] text-[var(--orange)]">PETA 30 LEVEL • RANDOM TETAP BISA FULL</p><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] mt-1 flex items-center gap-2"><MapIcon size={22} /> Peta 30 Level 🗺️</h2><p className="text-[13px] text-[var(--muted)] mt-1">Jual di level mana aja → kotak jadi hijau <b className="text-emerald-300">TERISI</b>.</p><div className="mt-3"><div className="progress-track h-2.5"><div className="progress-fill" style={{ width: `${filledPct}%` }} /></div><p className="text-xs text-[var(--muted)] mt-1.5">{filledPct}% terisi — {30 - filledCount} kotak lagi, gas!</p></div><div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-10 gap-2 mt-4">{Array.from({ length: 30 }, (_, i) => i + 1).map((n) => { const filled = game.filledLevels.includes(n); const active = n === game.level; return (<button key={n} onClick={() => playLevel(n)} className={`rounded-2xl border px-2 py-3 text-center ${filled ? "bg-emerald-500 text-emerald-950 border-emerald-500" : active ? "bg-orange-500 text-black border-orange-500" : "bg-[var(--surface-2)] border-[var(--line)]"}`}><span className="block font-display font-black text-base leading-none">Lv {n}</span><span className="block text-[10px] font-black mt-1.5 leading-none">{filled ? "✅ TERISI" : active ? "📍 KAMU" : "BELUM"}</span><span className="block text-[10px] mt-1 leading-tight opacity-80">{levelInfo(n).market.split(" (")[0].split(" / ")[0]}</span></button>); })}</div></div></section>

        <section ref={obsidianRef} id="obsidian" className="mt-8" aria-label="Pasar Obsidian"><div className="card p-4 sm:p-5 bg-gradient-to-br from-purple-900/30 to-[var(--surface)]"><p className="text-xs font-bold tracking-[0.18em] text-purple-300">PASAR KHUSUS • LEVEL 26–30</p><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] mt-1">💎 Obsidian — Toko Permata Mulia</h2><p className="text-[13px] text-[var(--muted)] leading-relaxed mt-1">Obsidian ke toko-toko permata mulia. Reward <b className="text-white">788 PTS per deal</b>. Klik lompat, langsung coba!</p><button onClick={jumpToGem} className="mt-3 bg-purple-600 text-white px-4 py-3 rounded-xl font-bold text-sm w-full sm:w-auto">🚀 Langsung ke Level 26-30 — Jual Obsidian</button><div className="mt-4 bg-black/30 border border-purple-400/50 rounded-2xl p-4"><h3 className="font-display font-black text-lg">💎 TENDER Obsidian — 20 Toko Gem Kecil</h3><p className="text-[13px] text-[var(--muted)] mt-1">788 × 20 = 15.760 + Design 2.000 + SAAS 500 = <b className="text-white">18.260 PTS</b>. Kalau DEAL: Level +3, Tender kebuka!</p><button onClick={() => { const b: Buyer = { id: "obsidian-tender", name: "TENDER Obsidian — 20 Toko Gem Kecil", place: "Toko Gem Kecil", type: "banyak", product: "Gem Lab Obsidian", qty: 20, unitPts: 788, desc: "Tender ke 20 toko gem kecil.", emoji: "💎", min: 26, max: 30 }; setSelectedBuyer(b); setQtyId("50"); setStage((s) => ({ ...s, notaVisible: true, buyerVisible: true, buyerPos: 34, buyerBubble: "Cek batu dong!", stageText: "TENDER Obsidian dipilih — Nota muncul! Lanjut Langkah 6–8." })); }} className="mt-3 btn-emerald w-full px-4 py-3.5 rounded-xl font-bold">Pilih TENDER Obsidian → 18.260 PTS</button></div></div></section>

        <section id="kartu" className="mt-8" aria-label="Toko Kartu"><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)]">🎴 Toko Kartu Bantuan</h2><p className="text-[var(--muted)] text-sm">Beli pakai PTS. Kartu aktif naikin peluang DEAL. Gagal berturut-turut: {game.failStreak}x • Total deal: {game.totalDeals}</p><div className="grid sm:grid-cols-3 gap-3 mt-4">{CARDS.map((c) => { const owned = game.ownedCards.includes(c.id); return (<article key={c.id} className={`card p-4 flex flex-col ${owned ? "border-emerald-500/60 bg-emerald-500/5" : ""}`}><div className="flex justify-between items-start"><span className="text-3xl">{c.emoji}</span>{owned && <span className="chip px-2.5 py-1 text-[11px] font-bold bg-emerald-500/20 border-emerald-500/50 text-emerald-200">AKTIF ✓</span>}</div><h3 className="font-display font-black text-lg mt-2">{c.name}</h3><p className="text-[11px] font-bold text-[var(--orange)]">{c.bonus}</p><p className="text-[13px] text-[var(--muted)] mt-1 flex-1">{c.desc}</p><p className="mt-2 font-black">{c.price} PTS</p><button disabled={owned} onClick={() => buyCard(c.id)} className={`mt-3 px-4 py-3 rounded-xl font-bold text-sm ${owned ? "btn-ghost opacity-70" : "btn-orange"}`}>{owned ? "Udah Punya ✓" : game.pts < c.price ? `PTS Kurang (${game.pts}/${c.price})` : `Beli Kartu — ${c.price} PTS`}</button></article>); })}</div></section>

        <section id="kontrak" className="mt-8" aria-label="Kontrak dan Teknisi"><h2 className="font-display font-black text-[clamp(1.3rem,5vw,1.8rem)] flex items-center gap-2"><FileText size={22} className="text-[var(--emerald-2)]" /> Kontrak & Teknisi ✍️🔧</h2><div className="mt-4 card p-4 sm:p-5"><div className="dialogue"><p className="text-[11px] font-bold tracking-widest text-[var(--orange)]">{boss.name.toUpperCase()} • BOSS SPONSOR</p><p className="text-[15px] leading-relaxed mt-1">“Lu bantu gue jualan, gue kasih lu <b>upah per produk terjual</b>, plus <b>teknisi gue yang rakitin dengan design</b>. Semua bisa gue cek dari HP gue.”</p></div><h3 className="font-bold mt-5">Tabel Upah PTS — Per Produk Terjual</h3><div className="mt-3 overflow-hidden rounded-xl border border-[var(--line)]"><div className="overflow-x-auto"><table className="w-full text-sm min-w-[420px]"><thead><tr className="bg-[var(--surface-3)] text-left"><th className="px-3 py-2.5 font-bold">Produk / Sistem</th><th className="px-3 py-2.5 text-right font-bold">Upah</th><th className="px-3 py-2.5 font-bold hidden sm:table-cell">Catatan</th></tr></thead><tbody>{CONTRACT.map((r) => (<tr key={r.name} className="border-t border-[var(--line)]"><td className="px-3 py-2.5 font-semibold">{r.name}</td><td className="px-3 py-2.5 text-right font-black text-[var(--emerald-2)] whitespace-nowrap">{r.pts} PTS</td><td className="px-3 py-2.5 text-[var(--muted)] hidden sm:table-cell">{r.note}</td></tr>))}</tbody></table></div></div><div className="mt-3 bg-[var(--surface-2)] rounded-xl p-3 text-[13px] text-[var(--muted)] leading-relaxed"><b className="text-white">Isi kontrak:</b> 1) Sales canvassing cari buyer • 2) Teknisi bikin full design + rakit • 3) Sponsor bayar upah PTS per produk laku • 4) Grosir = qty × upah + sistem • 5) TENDER = qty × upah + Design 2.000 + SAAS 500 + Sistem 600.</div></div></section>

        <section className="card-2 p-4 mt-5"><h4 className="font-bold flex items-center gap-2">📓 Log Cerita Terakhir</h4>{game.log.length === 0 ? <p className="text-sm text-[var(--muted)] mt-2">Belum ada log.</p> : <ul className="mt-2 space-y-1.5">{game.log.map((l, i) => <li key={i} className="text-[13px] text-[var(--muted)] flex gap-2"><span className="text-[var(--emerald-2)]">•</span><span>{l}</span></li>)}</ul>}</section>
        <footer className="mt-8 grid md:grid-cols-3 gap-3 text-[13px]"><div className="card-2 p-4"><b>Target menang:</b><p className="text-[var(--muted)] mt-1">5.000 PTS + 1 kontrak sponsor = KARIR SALES NAIK LEVEL!</p></div><div className="card-2 p-4"><b>ACAK + TENDER:</b><p className="text-[var(--muted)] mt-1">Semua level kebuka, random bebas, jual 1 unit naik level, tender lompat PTS gede.</p></div><div className="card-2 p-4"><b>Halo, {game.playerName || "Bro"}!</b><p className="text-[var(--muted)] mt-1">Progres tersimpan otomatis. Lanjut dari Level {game.level}.</p></div></footer>
        <p className="text-center text-[11px] text-[var(--muted)] mt-4">FULL VISUAL STORY • Canvassing • SAAS + 30 Level + Obsidian + Kartu • Email opsional, tidak memblokir game</p>
      </main>
    </div>
  );
}
